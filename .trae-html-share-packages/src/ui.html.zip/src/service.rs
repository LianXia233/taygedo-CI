//! 应用共享状态与业务编排。

use std::collections::HashMap;
use std::sync::Arc;

use tokio::sync::{Mutex, RwLock};

use crate::api::Api;
use crate::login::{self, DeviceIdentity};
use crate::models::{Account, AccountResult, Config, LogEntry, RunResult};
use crate::runner::{self, RunOptions};
use crate::session::CryptoManager;
use crate::store::Store;

pub struct AppState {
    pub api: Api,
    pub store: Store,
    pub accounts: RwLock<Vec<Account>>,
    pub config: RwLock<Config>,
    pub state: RwLock<HashMap<String, String>>,
    pub logs: std::sync::Mutex<Vec<LogEntry>>,
    /// 验证码设备身份：phone -> (identity, 发送时间 unix 秒)。带 TTL，防内存泄漏。
    pub pending_devices: std::sync::Mutex<HashMap<String, (DeviceIdentity, i64)>>,
    pub run_lock: Mutex<()>,
    /// 登录会话：token -> (过期 unix 秒, 所属用户名)。
    pub sessions: std::sync::Mutex<HashMap<String, (i64, String)>>,
    /// WebUI 登录失败计数：username -> (失败次数, 锁定截止 unix 秒)。防暴力破解。
    pub login_fails: std::sync::Mutex<HashMap<String, (u32, i64)>>,
    /// 免鉴权模式：为 true 时所有 API 无需登录即可访问。
    /// **仅 OpenWrt 平台（LuCI 配套使用）生效**，非 OpenWrt 环境即使设置环境变量也会被强制关闭。
    pub no_auth: bool,
    /// 当前运行平台是否 OpenWrt。
    ///
    /// 保留：`no_auth` 的生效范围判定与之相关，供前端与后续分支逻辑读取。
    #[allow(dead_code)]
    pub is_openwrt: bool,
    /// 应用层加密会话管理器。
    pub crypto: CryptoManager,
    /// 启动时生成的初始随机口令（**仅保存在内存**，用于单次提示，不落盘、不进日志）。
    pub initial_password: Option<String>,
    /// 内网来源判定器。运行期可经 `/api/config` 热更新，故用 Arc 包裹。
    pub lan: std::sync::RwLock<Arc<LanMatcher>>,
}

impl AppState {
    pub fn new(data_dir: std::path::PathBuf) -> Arc<Self> {
        let store = Store::new(data_dir);
        let accounts = store.load_accounts();
        let mut config = store.load_config();

        // 环境变量覆盖（向后兼容：高级用户可手动设置覆盖 config.json；
        // OpenWrt/LuCI 的 init.d 已不再传入业务配置，业务配置统一由 config.json 管理）
        if let Ok(v) = std::env::var("TAYGEDO_DEFAULT_SCHEDULE") {
            if !v.trim().is_empty() {
                config.default_schedule = v.trim().to_string();
            }
        }
        if let Ok(v) = std::env::var("TAYGEDO_COIN_TASKS") {
            config.coin_tasks = parse_bool_env(&v);
        }
        if let Ok(v) = std::env::var("TAYGEDO_CLOUD_DURATION") {
            config.cloud_duration = parse_bool_env(&v);
        }
        if let Ok(v) = std::env::var("TAYGEDO_SHARE_PLATFORM") {
            if !v.trim().is_empty() {
                config.share_platform = v.trim().to_string();
            }
        }
        // 应用层加密策略可由环境变量覆盖（OpenWrt UCI 经 init.d 传入）
        if let Ok(v) = std::env::var("TAYGEDO_CRYPTO_POLICY") {
            if let Some(p) = normalize_crypto_policy(&v) {
                config.crypto_policy = p;
            }
        }
        // 内网网段白名单覆盖：空值视为「未设置」，保留 config.json 中的值
        // （把空串写进去会把白名单清空，导致内网免鉴权与 auto 豁免双双失效）
        if let Ok(v) = std::env::var("TAYGEDO_LAN_CIDRS") {
            if !v.trim().is_empty() {
                config.lan_cidrs = v.trim().to_string();
            }
        }
        // 内网免鉴权放行开关覆盖
        if let Ok(v) = std::env::var("TAYGEDO_LAN_NO_AUTH") {
            config.lan_no_auth = parse_bool_env(&v);
        }

        // 首次启动若没有凭据密钥，立即落盘
        if config.credential_key.is_empty() {
            config.credential_key = crate::crypto::generate_credential_key();
        }

        // 用户名初始化（默认 admin）
        if config.web_username.as_deref().map(|s| s.trim().is_empty()).unwrap_or(true) {
            config.web_username = Some("admin".into());
        }

        // 长期身份密钥环：不存在则生成；损坏则保留原文件并用内存临时密钥，
        // 避免"悄悄重建"导致已固化客户端指纹的部署无法连接。
        let keyring = match store.load_keyring() {
            Some(kr) => match kr.secret_bytes() {
                Ok(s) => Some(s),
                Err(e) => {
                    eprintln!("[startup] keyring 私钥非法（{e}），改用内存临时密钥（不落盘）");
                    None
                }
            },
            None => None,
        };
        let (identity_secret, keyring_created) = match keyring {
            Some(s) => (s, false),
            None => {
                let kr = crate::models::KeyRing::generate();
                let s = kr.secret_bytes().expect("新生成的密钥必合法");
                match store.save_keyring_if_absent(&kr) {
                    Ok(true) => (s, true),
                    Ok(false) => {
                        // 文件存在但内容不可用：不覆盖，本次运行使用内存临时密钥
                        eprintln!("[startup] keyring.json 已存在但无法解析，本次使用内存临时密钥");
                        (s, false)
                    }
                    Err(e) => {
                        eprintln!("[startup] 保存 keyring 失败（{e}），继续使用内存临时密钥");
                        (s, false)
                    }
                }
            }
        };
        let crypto = CryptoManager::new(identity_secret);

        // WebUI 口令初始化：优先环境变量；否则生成随机口令，杜绝默认 admin。
        let mut initial_password: Option<String> = None;
        if config.web_password_hash.is_none() {
            let env_pwd = std::env::var("TAYGEDO_WEB_PASSWORD")
                .ok()
                .filter(|s| !s.trim().is_empty());
            let (password, must_change) = match env_pwd {
                Some(p) => (p, false),
                None => (crate::crypto::generate_passphrase(16), true),
            };
            let salt = crate::crypto::random_hex(16);
            config.web_password_hash = Some(crate::crypto::hash_password_v2(&password, &salt));
            config.web_password_salt = Some(salt);
            config.web_password_version = Some(crate::crypto::PWD_HASH_V2);
            config.web_password_must_change = must_change;
            initial_password = Some(password);
        }
        // 兼容历史配置：v1（单轮 sha256 + 8 字节盐）在口令校验通过后就地升级为 v2
        if config.web_password_version.is_none() {
            config.web_password_version = Some(crate::crypto::PWD_HASH_V1);
        }
        store.save_config(&config).unwrap_or_else(|e| {
            eprintln!("[startup] 保存 config 失败: {e}");
        });

        // 免鉴权模式：环境变量 TAYGEDO_NO_AUTH=1/true/yes/on 时开启。
        // **OpenWrt 专享**：仅 OpenWrt（存在 /etc/openwrt_release）平台生效；
        // 其他平台（Windows / Linux 服务器 / Docker 等）即使设置环境变量也会被强制关闭，
        // 避免免鉴权被误开在公网环境造成安全风险。
        let openwrt = is_openwrt();
        let no_auth_env = std::env::var("TAYGEDO_NO_AUTH")
            .map(|v| parse_bool_env(&v))
            .unwrap_or(false);
        let no_auth = no_auth_env && openwrt;

        let lan = LanMatcher::new(&config.lan_cidrs);

        let state = store.load_state();
        let app = Arc::new(Self {
            api: Api::new(),
            store,
            accounts: RwLock::new(accounts),
            config: RwLock::new(config),
            state: RwLock::new(state),
            logs: std::sync::Mutex::new(Vec::new()),
            pending_devices: std::sync::Mutex::new(HashMap::new()),
            run_lock: Mutex::new(()),
            sessions: std::sync::Mutex::new(HashMap::new()),
            login_fails: std::sync::Mutex::new(HashMap::new()),
            no_auth,
            is_openwrt: openwrt,
            crypto,
            initial_password: initial_password.clone(),
            lan: std::sync::RwLock::new(Arc::new(lan)),
        });

        if keyring_created {
            app.push_log(
                "info",
                "已生成长期身份密钥 data/keyring.json（权限 600）。请纳入备份，\
                 丢失后需重新固化客户端指纹。"
                    .into(),
            );
        }
        if let Some(w) = app.store.keyring_permission_warning() {
            app.push_log("warn", format!("密钥文件权限过宽：{w}"));
        }
        if initial_password.is_some() {
            // 不再把明文口令写入日志缓冲区（日志可经 /api/logs 读取）。
            // 明文仅在 stdout 首次启动横幅中出现一次，供操作者记录。
            app.push_log(
                "warn",
                "已初始化 WebUI 登录账号 admin，口令为本次启动随机生成，\
                 请在启动横幅中查看并首次登录后立即修改。"
                    .into(),
            );
        }
        if no_auth_env && !openwrt {
            app.push_log(
                "warn",
                "检测到 TAYGEDO_NO_AUTH=1，但当前非 OpenWrt 平台：免鉴权模式已强制关闭，请使用 WebUI 账号密码登录".into(),
            );
        } else if no_auth {
            app.push_log(
                "warn",
                "免鉴权模式已开启（OpenWrt 专享）：API 无需登录即可访问，仅限内网使用".into(),
            );
        }
        app
    }

    /// 判定来源是否可享受免鉴权放行。
    ///
    /// 即使 `no_auth` 已开启，非内网来源也不放行——避免"免鉴权开关被打开
    /// 后服务被直接暴露到公网"这一配置失误演变为完全开放。
    pub async fn no_auth_allows(&self, peer_ip: Option<std::net::IpAddr>) -> bool {
        if !self.no_auth {
            return false;
        }
        let lan_ok = self.config.read().await.lan_no_auth;
        if !lan_ok {
            // 未启用 LAN 白名单时，按原语义放行全部来源（保持向后兼容）
            return true;
        }
        match peer_ip {
            Some(ip) => self.lan_matches(ip),
            // 无法解析来源（如 Unix socket / 代理未透传）时保守放行：
            // 免鉴权模式本身即为内网自用设计，此处不额外收紧以免破坏既有部署。
            None => true,
        }
    }

    /// 按当前（可热更新的）内网网段判定来源 IP 是否属于 LAN。
    pub fn lan_matches(&self, ip: std::net::IpAddr) -> bool {
        self.lan
            .read()
            .map(|m| m.contains(ip))
            .unwrap_or(false)
    }

    /// 用新的 CIDR 串替换内网匹配器（配置变更时热更新）。
    pub fn set_lan_cidrs(&self, cidrs: &str) -> Result<(), String> {
        let matcher = LanMatcher::from_cidrs(cidrs)?;
        let mut guard = self.lan.write().map_err(|_| "内网匹配器锁中毒")?;
        *guard = Arc::new(matcher);
        Ok(())
    }


    pub fn push_log(&self, level: &str, message: String) {
        let ts = crate::time::log_ts();
        let mut logs = self.logs.lock().unwrap();
        logs.push(LogEntry {
            ts,
            level: level.to_string(),
            message,
        });
        if logs.len() > 500 {
            let excess = logs.len() - 500;
            logs.drain(0..excess);
        }
    }

    pub fn recent_logs(&self, limit: usize) -> Vec<LogEntry> {
        let logs = self.logs.lock().unwrap();
        let start = logs.len().saturating_sub(limit);
        logs[start..].to_vec()
    }

    /// 校验登录账号密码。
    ///
    /// 按 `web_password_version` 选择哈希算法：v2（scrypt）为当前格式，
    /// v1（单轮 sha256）仅用于兼容历史配置。两者均使用恒定时间比较。
    pub async fn verify_login(&self, username: &str, password: &str) -> bool {
        let config = self.config.read().await;
        let expected_user = config.web_username.as_deref().unwrap_or("admin");
        // 用户名比较也走恒定时间，避免枚举有效用户名
        if !crate::crypto::constant_time_eq(username.as_bytes(), expected_user.as_bytes()) {
            return false;
        }
        match (&config.web_password_hash, &config.web_password_salt) {
            (Some(hash), Some(salt)) => {
                let version = config.web_password_version.unwrap_or(crate::crypto::PWD_HASH_V1);
                let computed = if version >= crate::crypto::PWD_HASH_V2 {
                    crate::crypto::hash_password_v2(password, salt)
                } else {
                    crate::crypto::hash_password(password, salt)
                };
                crate::crypto::constant_time_eq(computed.as_bytes(), hash.as_bytes())
            }
            _ => false,
        }
    }

    /// 历史 v1 口令校验通过后就地升级为 v2。
    ///
    /// 仅在**校验成功**后调用，因此不会把错误口令固化为新哈希。
    pub async fn upgrade_password_hash_if_legacy(&self, password: &str) -> bool {
        let needs_upgrade = {
            let config = self.config.read().await;
            config
                .web_password_version
                .unwrap_or(crate::crypto::PWD_HASH_V1)
                < crate::crypto::PWD_HASH_V2
        };
        if !needs_upgrade {
            return false;
        }
        let mut config = self.config.write().await;
        let salt = crate::crypto::random_hex(16);
        config.web_password_hash = Some(crate::crypto::hash_password_v2(password, &salt));
        config.web_password_salt = Some(salt);
        config.web_password_version = Some(crate::crypto::PWD_HASH_V2);
        if let Err(e) = self.store.save_config(&config) {
            self.push_log("error", format!("升级口令哈希失败: {e}"));
            return false;
        }
        true
    }

    /// 修改登录账号与口令。成功后**吊销该用户全部会话**。
    pub async fn set_credentials(
        &self,
        username: &str,
        new_password: &str,
    ) -> Result<(), String> {
        {
            let mut config = self.config.write().await;
            if !username.trim().is_empty() {
                config.web_username = Some(username.trim().to_string());
            }
            let salt = crate::crypto::random_hex(16);
            config.web_password_hash = Some(crate::crypto::hash_password_v2(new_password, &salt));
            config.web_password_salt = Some(salt);
            config.web_password_version = Some(crate::crypto::PWD_HASH_V2);
            // 使用者已自行设置口令，撤销"必须修改口令"状态
            config.web_password_must_change = false;
            self.store.save_config(&config)?;
        }
        // 口令变更后立即吊销全部既有会话，堵住"凭据已泄露但旧 token 仍有效"的窗口
        let revoked = self.revoke_all_sessions();
        // 加密会话同样作废，强制全端重新握手
        let crypto_revoked = self.crypto.destroy_all();
        self.push_log(
            "info",
            format!("登录口令已更新，已吊销 {revoked} 个会话 / {crypto_revoked} 个加密会话"),
        );
        Ok(())
    }

    /// 轮换长期身份密钥（供显式操作调用；需使用者确认）。
    ///
    /// 运维接口：当前没有 UI 入口 —— 轮换会让所有已固化身份指纹的客户端
    /// 弹出"身份已变化"提示，属于需要人工确认的操作，故保留给 CLI /
    /// 未来的管理入口调用，不自动触发。
    #[allow(dead_code)]
    pub fn rotate_identity_key(&self) -> Result<(), String> {
        let mut kr = crate::models::KeyRing::generate();
        let existing_gen = self.store.load_keyring().map(|k| k.generation).unwrap_or(0);
        kr.generation = existing_gen + 1;
        self.store.save_keyring(&kr)
    }

    /// 签发登录 token（有效期 7 天）。token 与该用户名绑定，便于按用户吊销。
    pub fn issue_token(&self, username: &str) -> String {
        let token = crate::crypto::random_hex(32);
        let expiry = now_unix() + SESSION_TTL_SECS;
        self.sessions
            .lock()
            .unwrap()
            .insert(token.clone(), (expiry, username.to_string()));
        token
    }

    /// 校验 token，返回所属用户名。
    pub fn validate_token(&self, token: &str) -> Option<String> {
        if token.is_empty() {
            return None;
        }
        // 形态前置校验：拒绝非法长度，减少无谓的锁竞争
        if token.len() != 64 || !token.bytes().all(|b| b.is_ascii_hexdigit()) {
            return None;
        }
        let now = now_unix();
        let mut sessions = self.sessions.lock().unwrap();
        sessions.retain(|_, (exp, _)| *exp > now);
        sessions.get(token).map(|(_, user)| user.clone())
    }

    /// 吊销单个会话。
    pub fn revoke_session(&self, token: &str) -> bool {
        self.sessions.lock().unwrap().remove(token).is_some()
    }

    /// 吊销全部登录会话，返回吊销数量。
    pub fn revoke_all_sessions(&self) -> usize {
        let mut s = self.sessions.lock().unwrap();
        let n = s.len();
        s.clear();
        n
    }

    /// 当前有效会话数。
    ///
    /// 诊断接口：顺带清理已过期条目。当前无调用点，保留供运维排查
    /// "为什么旧 token 还能用"之类的问题。
    #[allow(dead_code)]
    pub fn active_sessions(&self) -> usize {
        let now = now_unix();
        let mut s = self.sessions.lock().unwrap();
        s.retain(|_, (exp, _)| *exp > now);
        s.len()
    }

    /// 是否需要强制修改口令（初始为随机口令时为真）。
    pub async fn must_change_password(&self) -> bool {
        self.config.read().await.web_password_must_change
    }


    /// 是否处于登录锁定。返回 Some(剩余秒数) 表示已锁定。
    pub fn login_lock_remaining(&self, username: &str) -> Option<i64> {
        let now = now_unix();
        let fails = self.login_fails.lock().unwrap();
        match fails.get(username) {
            Some((count, lock_until)) if *count >= MAX_LOGIN_FAILS && *lock_until > now => {
                Some(*lock_until - now)
            }
            _ => None,
        }
    }

    /// 记录一次登录失败；连续失败达到阈值后锁定 5 分钟。
    pub fn record_login_fail(&self, username: &str) {
        let now = now_unix();
        let mut fails = self.login_fails.lock().unwrap();
        let entry = fails.entry(username.to_string()).or_insert((0, 0));
        entry.0 += 1;
        if entry.0 >= MAX_LOGIN_FAILS {
            entry.1 = now + LOGIN_LOCK_SECS;
        }
        if entry.0 > MAX_LOGIN_FAILS * 3 {
            // 防止无限膨胀
            entry.0 = MAX_LOGIN_FAILS;
            entry.1 = now + LOGIN_LOCK_SECS;
        }
    }

    /// 登录成功后清除失败计数。
    pub fn reset_login_fails(&self, username: &str) {
        self.login_fails.lock().unwrap().remove(username);
    }
}

/// WebUI 登录连续失败阈值。
pub const MAX_LOGIN_FAILS: u32 = 5;
/// 达到阈值后的锁定时长（秒）。
pub const LOGIN_LOCK_SECS: i64 = 300;
/// 登录会话有效期（秒，7 天）。
pub const SESSION_TTL_SECS: i64 = 7 * 24 * 3600;

/// 内网来源匹配器。
///
/// 用于两处判断：
/// 1. `no_auth` 模式下是否放行该来源（LAN 白名单）；
/// 2. `crypto_policy = auto` 时该来源是否必须启用应用层加密。
pub struct LanMatcher {
    nets: Vec<(ipnet::IpNet, bool)>,
}

impl LanMatcher {
    /// 从逗号分隔的 CIDR 串构造。非法条目被忽略并告警（不 panic）。
    pub fn new(cidrs: &str) -> Self {
        let mut nets = Vec::new();
        for part in cidrs.split(',') {
            let t = part.trim();
            if t.is_empty() {
                continue;
            }
            match t.parse::<ipnet::IpNet>() {
                Ok(n) => nets.push((n, true)),
                Err(_) => eprintln!("[lan] 忽略非法 CIDR: {t}"),
            }
        }
        Self { nets }
    }

    /// 严格构造：任一条目非法即返回 Err。
    ///
    /// 与 [`LanMatcher::new`] 的差异在于**配置写入路径必须用严格模式**——
    /// 静默忽略非法网段会让用户以为已收紧范围，实际却是空集合（全放行或
    /// 全拒绝），属于危险的静默降级。运行时热更新走这里做前置校验。
    pub fn from_cidrs(cidrs: &str) -> Result<Self, String> {
        let mut nets = Vec::new();
        for part in cidrs.split(',') {
            let t = part.trim();
            if t.is_empty() {
                continue;
            }
            match t.parse::<ipnet::IpNet>() {
                Ok(n) => nets.push((n, true)),
                Err(_) => return Err(format!("非法网段：{t}")),
            }
        }
        Ok(Self { nets })
    }

    /// 该 IP 是否属于内网白名单。
    pub fn contains(&self, ip: std::net::IpAddr) -> bool {
        // IPv4-mapped IPv6（::ffff:192.168.1.1）统一归一为 IPv4 再匹配
        let ip = match ip {
            std::net::IpAddr::V6(v6) => match v6.to_ipv4_mapped() {
                Some(v4) => std::net::IpAddr::V4(v4),
                None => std::net::IpAddr::V6(v6),
            },
            v4 => v4,
        };
        self.nets.iter().any(|(net, _)| net.contains(&ip))
    }
}

/// 规范化加密策略字符串。非法值返回 None。
pub fn normalize_crypto_policy(v: &str) -> Option<String> {
    match v.trim().to_lowercase().as_str() {
        "auto" => Some("auto".into()),
        "always" | "on" | "1" | "true" | "yes" => Some("always".into()),
        "never" | "off" | "0" | "false" | "no" => Some("never".into()),
        _ => None,
    }
}

/// 当前是否运行在 OpenWrt（存在 /etc/openwrt_release 即视为 OpenWrt）。
pub fn is_openwrt() -> bool {
    std::path::Path::new("/etc/openwrt_release").exists()
}

fn now_unix() -> i64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

fn parse_bool_env(v: &str) -> bool {
    matches!(v.trim().to_lowercase().as_str(), "1" | "true" | "yes" | "on")
}

/// 执行签到（手动触发或调度触发）。`only` 为 None 时运行全部账号。
pub async fn run_signin(state: &AppState, force: bool, only: Option<&[String]>) -> RunResult {
    let _guard = state.run_lock.lock().await;
    let started_at = crate::time::shanghai_datetime();
    let today = crate::time::shanghai_date();

    state.push_log("info", format!("开始执行签到：forceRun={force}"));

    let accounts = state.accounts.read().await.clone();
    let config = state.config.read().await.clone();
    let credential_key = config.credential_key.clone();
    let opts = RunOptions {
        coin_tasks: config.coin_tasks,
        cloud_duration: config.cloud_duration,
        share_platform: config.share_platform.clone(),
    };

    let mut updated_accounts = accounts.clone();
    let mut results: Vec<AccountResult> = Vec::new();
    let state_map = state.state.read().await.clone();
    // id → 索引，避免内层循环 O(n²)
    let mut updated_by_id: HashMap<String, usize> = HashMap::new();
    for (i, a) in updated_accounts.iter().enumerate() {
        updated_by_id.insert(a.id.clone(), i);
    }

    for account in &accounts {
        if let Some(ids) = only {
            if !ids.contains(&account.id) {
                continue;
            }
        }
        let already = state_map.get(&account.id).map(|d| d == &today).unwrap_or(false);
        if !force && already {
            state.push_log(
                "info",
                format!("账号 {}（{}）：今日已成功签到，跳过", account.name, account.id),
            );
            results.push(AccountResult {
                id: account.id.clone(),
                name: account.name.clone(),
                status: "skipped".into(),
                app_signin: None,
                game_signins: vec![],
                coin_tasks: None,
                cloud_duration: None,
                error: None,
                skipped_reason: Some("今天已成功签到".into()),
            });
            continue;
        }

        state.push_log("info", format!("账号 {}（{}）：开始签到", account.name, account.id));
        let mut cb = |m: String| {
            state.push_log("info", m);
        };
        match runner::run_account(&state.api, account, Some(&credential_key), &opts, &mut cb).await {
            Ok((updated, res)) => {
                if let Some(&idx) = updated_by_id.get(account.id.as_str()) {
                    updated_accounts[idx] = updated;
                }
                results.push(res);
            }
            Err(e) => {
                state.push_log(
                    "error",
                    format!("账号 {}（{}）：签到失败：{}", account.name, account.id, e.0),
                );
                results.push(AccountResult {
                    id: account.id.clone(),
                    name: account.name.clone(),
                    status: "failed".into(),
                    app_signin: None,
                    game_signins: vec![],
                    coin_tasks: None,
                    cloud_duration: None,
                    error: Some(e.0),
                    skipped_reason: None,
                });
            }
        }
    }

    // 更新已签到状态
    let mut new_state = state_map.clone();
    for r in &results {
        if r.status == "success" {
            new_state.insert(r.id.clone(), today.clone());
        }
    }

    *state.accounts.write().await = updated_accounts.clone();
    if let Err(e) = state.store.save_accounts(&updated_accounts) {
        state.push_log("error", format!("保存账号数据失败: {e}"));
    }
    *state.state.write().await = new_state.clone();
    if let Err(e) = state.store.save_state(&new_state) {
        state.push_log("error", format!("保存签到状态失败: {e}"));
    }

    let success_count = results.iter().filter(|r| r.status == "success").count();
    let failed_count = results.iter().filter(|r| r.status == "failed").count();
    let skipped_count = results.iter().filter(|r| r.status == "skipped").count();
    let finished_at = crate::time::shanghai_datetime();

    let mut result = RunResult {
        started_at,
        finished_at,
        success_count,
        failed_count,
        skipped_count,
        accounts: results,
        summary: String::new(),
    };
    result.summary = runner::summary_text(&result);
    state.push_log("info", result.summary.clone());
    state.push_log(
        "info",
        format!("签到结束：成功 {}，失败 {}，跳过 {}", success_count, failed_count, skipped_count),
    );

    result
}

/// 验证码设备身份有效期（秒）。
const PENDING_DEVICE_TTL: i64 = 600;
/// 同一手机号验证码重发冷却（秒）。
const CAPTCHA_COOLDOWN_SECS: i64 = 60;

/// 发送短信验证码。
pub async fn send_code(state: &AppState, phone: &str) -> Result<(), String> {
    let now = now_unix();
    // 冷却 + 过期清理
    {
        let mut pending = state.pending_devices.lock().unwrap();
        pending.retain(|_, (_, sent_at)| now - *sent_at < PENDING_DEVICE_TTL);
        if let Some((_, sent_at)) = pending.get(phone) {
            let remaining = CAPTCHA_COOLDOWN_SECS - (now - *sent_at);
            if remaining > 0 {
                return Err(format!("验证码发送过于频繁，请 {remaining} 秒后重试"));
            }
        }
    }

    let identity = login::generate_device_identity();
    state
        .api
        .send_captcha(phone, &identity.device_id)
        .await
        .map_err(|e| e.0)?;
    state
        .pending_devices
        .lock()
        .unwrap()
        .insert(phone.to_string(), (identity, now));
    Ok(())
}

/// 登录账号（密码或验证码）。
pub async fn login_account(
    state: &AppState,
    phone: &str,
    mode: &str,
    password: Option<&str>,
    captcha: Option<&str>,
    name: Option<&str>,
) -> Result<Account, String> {
    let identity = if mode == "password" {
        login::generate_device_identity()
    } else {
        let mut pending = state.pending_devices.lock().unwrap();
        let now = now_unix();
        match pending.remove(phone) {
            Some((dev, sent_at)) if now - sent_at < PENDING_DEVICE_TTL => dev,
            Some(_) => return Err("验证码已过期，请重新发送".to_string()),
            None => return Err("请先发送验证码".to_string()),
        }
    };

    let (token, user_id) = if mode == "password" {
        let pwd = password.ok_or_else(|| "缺少密码".to_string())?;
        state
            .api
            .login_with_password(phone, pwd, &identity.device_id)
            .await
            .map_err(|e| e.0)?
    } else {
        let cap = captcha.ok_or_else(|| "缺少验证码".to_string())?;
        state
            .api
            .login_with_captcha(phone, cap, &identity.device_id)
            .await
            .map_err(|e| e.0)?
    };

    let (access_token, refresh_token, uid) = state
        .api
        .user_center_login(&token, &user_id, &identity.device_id)
        .await
        .map_err(|e| e.0)?;

    let bind_role = state
        .api
        .get_bind_role(&access_token, &uid, "1256")
        .await
        .unwrap_or(None);

    let mut account = Account {
        id: login::gen_account_id(),
        name: name
            .filter(|n| !n.trim().is_empty())
            .map(|n| n.to_string())
            .unwrap_or_else(|| login::gen_account_name(phone)),
        uid: uid.clone(),
        device_id: identity.device_id,
        openudid: Some(identity.openudid),
        vendorid: Some(identity.vendorid),
        access_token: Some(access_token),
        refresh_token,
        laohu_token: Some(token),
        laohu_user_id: Some(user_id),
        token_updated_at: Some(crate::time::shanghai_datetime()),
        phone: Some(phone.to_string()),
        encrypted_password: None,
        role_id: bind_role.as_ref().map(|(rid, _)| rid.clone()),
        role_name: bind_role.as_ref().and_then(|(_, rn)| rn.clone()),
    };

    if mode == "password" {
        if let Some(pwd) = password {
            let ck = state.config.read().await.credential_key.clone();
            account.encrypted_password = Some(crate::crypto::encrypt_password(pwd, &ck));
        }
    }

    // upsert by phone
    let mut accounts = state.accounts.write().await;
    let existing = accounts.iter().position(|a| a.phone.as_deref() == Some(phone));
    match existing {
        Some(idx) => {
            let old = &accounts[idx];
            account.id = old.id.clone();
            if name.is_none() {
                account.name = old.name.clone();
            }
            accounts[idx] = account.clone();
        }
        None => {
            accounts.push(account.clone());
        }
    }
    state.store.save_accounts(&accounts).unwrap_or_else(|e| {
        eprintln!("[service] 保存账号数据失败: {e}");
    });

    Ok(account)
}

/// 删除账号。同步清理 state.json 签到记录与 config.schedules 定时配置，避免残留幽灵数据。
pub async fn delete_account(state: &AppState, id: &str) -> bool {
    let mut accounts = state.accounts.write().await;
    let before = accounts.len();
    accounts.retain(|a| a.id != id);
    let changed = accounts.len() != before;
    if changed {
        if let Err(e) = state.store.save_accounts(&accounts) {
            state.push_log("error", format!("保存账号数据失败: {e}"));
        }
        // 清理签到状态与定时配置
        let mut state_map = state.state.write().await;
        if state_map.remove(id).is_some() {
            if let Err(e) = state.store.save_state(&state_map) {
                state.push_log("error", format!("保存签到状态失败: {e}"));
            }
        }
        let mut config = state.config.write().await;
        if config.schedules.remove(id).is_some() {
            if let Err(e) = state.store.save_config(&config) {
                state.push_log("error", format!("保存配置失败: {e}"));
            }
        }
        state.push_log("info", format!("已删除账号 {id}（含签到记录与定时配置）"));
    }
    changed
}

/// 设置账号签到时间。
pub async fn set_schedule(state: &AppState, id: &str, time: Option<&str>) -> Result<(), String> {
    if let Some(t) = time {
        if !crate::time::valid_hhmm(t) {
            return Err("时间格式应为 HH:MM".into());
        }
    }
    let mut config = state.config.write().await;
    match time {
        Some(t) => {
            config.schedules.insert(id.to_string(), t.to_string());
        }
        None => {
            config.schedules.remove(id);
        }
    }
    state.store.save_config(&config).map_err(|e| e)?;
    Ok(())
}
